<br><br><br>
    <div class="container text-center" style="margin: 2em auto;">
      <div class="jumbotron">
        <h1 class="display-3">Welcome</h1>
        <p class="lead">Aplikasi Gudang Yang Dibuat Sederhana</p>
    </div>
  </div>
