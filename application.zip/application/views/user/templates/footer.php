  <footer class="cp-footer">
    <div class="container">
        <h3 class="title-footer">Copyright Web Gudang &copy; <?=date('Y')?></h3>
    </div>
  </footer>
  </body>
</html>
